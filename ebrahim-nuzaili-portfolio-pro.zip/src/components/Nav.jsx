import React from 'react'

export default function Nav(){ 
  return (
    <header className="fixed w-full z-30 top-0 left-0">
      <div className="backdrop-blur-sm bg-black/30 border-b border-white/6">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="text-sm font-semibold">Ebrahim Nuzaili <span className="text-gray-400">| Software Engineer</span></div>
          <nav className="hidden md:flex gap-6 text-sm text-gray-300">
            <a href="#about" className="hover:text-white">About</a>
            <a href="#experience" className="hover:text-white">Experience</a>
            <a href="#projects" className="hover:text-white">Projects</a>
            <a href="#contact" className="hover:text-white">Contact</a>
          </nav>
        </div>
      </div>
    </header>
  )
}