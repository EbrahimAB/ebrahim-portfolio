import React from 'react'
export default function Section({id,children}){
  return <section id={id} className="container mx-auto px-6 py-20">{children}</section>
}