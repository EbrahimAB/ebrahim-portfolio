
import React from 'react'
import Nav from './components/Nav.jsx'
import Section from './components/Section.jsx'

export default function App(){
  const profile = '/assets/profile.png'
  const cv = '/assets/cv.pdf'
  return (
    <div className="min-h-screen">
      <Nav />
      <main className="pt-24">
        <Section id="hero">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6">Hi — I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-pink-500">Ebrahim Nuzaili</span></h1>
            <p className="text-gray-300 text-lg md:text-xl max-w-2xl mx-auto mb-8">
              Multilanguage software engineer and tester with practical experience in building, testing, and optimizing applications across web and AI-driven platforms.
            </p>
            <div className="flex items-center justify-center gap-4">
              <a href={cv} target="_blank" rel="noreferrer" className="px-6 py-3 rounded-md bg-gradient-to-r from-accent to-pink-500 text-white font-medium shadow-lg">View CV</a>
              <a href={cv} download className="px-5 py-3 rounded-md border border-white/10 text-sm">Download</a>
            </div>
          </div>
        </Section>

        <Section id="about">
          <div className="flex flex-col md:flex-row items-center gap-10">
            <div className="md:w-1/2">
              <h2 className="text-2xl font-semibold mb-4">About</h2>
              <p className="text-gray-300 leading-relaxed">
                Multilanguage software developer and tester with practical experience in building, testing, and optimizing applications across web and AI-driven platforms. Skilled in full-stack development, software quality assurance, and automation testing. Enthusiastic about artificial intelligence, machine learning, and data-driven solutions, with a passion for creating scalable, reliable, and intelligent systems.
              </p>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="w-56 h-56 rounded-2xl overflow-hidden ring-1 ring-white/6">
                <img src={profile} alt="Ebrahim" className="object-cover w-full h-full"/>
              </div>
            </div>
          </div>
        </Section>

        <Section id="experience">
          <h3 className="text-2xl font-semibold mb-6">Experience</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <article className="p-6 bg-white/3 rounded-lg border border-white/6">
              <h4 className="font-semibold">Software Tester — Addicta Co.</h4>
              <p className="text-sm text-gray-400">June 2025 - Present</p>
              <p className="mt-3 text-gray-300">Design and execute test plans, perform functional and regression testing...</p>
            </article>
            <article className="p-6 bg-white/3 rounded-lg border border-white/6">
              <h4 className="font-semibold">IT Engineer — UTM Digital</h4>
              <p className="text-sm text-gray-400">June 2024 - April 2025</p>
              <p className="mt-3 text-gray-300">Support and troubleshoot hardware/software, maintain IT services...</p>
            </article>
          </div>
        </Section>

        <Section id="projects">
          <h3 className="text-2xl font-semibold mb-6">Projects</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <article className="p-6 bg-white/3 rounded-lg border border-white/6">
              <h4 className="font-semibold">ScanDrum - Inventory Management</h4>
              <p className="text-sm text-gray-400">Django, PostgreSQL</p>
              <p className="mt-2 text-gray-300">Backend with REST APIs, JWT auth and Dockerized deployment.</p>
            </article>
            <article className="p-6 bg-white/3 rounded-lg border border-white/6">
              <h4 className="font-semibold">Task Automation Bot</h4>
              <p className="text-sm text-gray-400">Python, Google Sheets API</p>
              <p className="mt-2 text-gray-300">Automated reporting tasks and Slack integration.</p>
            </article>
          </div>
        </Section>

        <Section id="contact">
          <h3 className="text-2xl font-semibold mb-6">Contact</h3>
          <div className="max-w-2xl">
            <p className="text-gray-300 mb-3">Email: <a className="text-accent" href="mailto:ebrahimaanuzaili@gmail.com">ebrahimaanuzaili@gmail.com</a></p>
            <p className="text-gray-300 mb-3">Phone: +966 565800327</p>
            <p className="text-gray-400">LinkedIn: <a className="text-accent" href="https://www.linkedin.com/in/ebrahim-nuzaili" target="_blank" rel="noreferrer">/ebrahim-nuzaili</a></p>
          </div>
        </Section>

        <footer className="py-12 text-center text-sm text-gray-500">© {new Date().getFullYear()} Ebrahim Nuzaili — Built with React & Tailwind</footer>
      </main>
    </div>
  )
}
